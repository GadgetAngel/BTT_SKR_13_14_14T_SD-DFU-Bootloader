Stock firmware extracted via SWD from Bigtreetech SKR E3-DIP V1.0 
with STM32F103RET6, shipped 2019-09-18
